/*

	FoxNet: The Fox Project's Communication Protocol Implementation Effort
	Edoardo Biagioni (Edoardo.Biagioni@cs.cmu.edu)
	Ken Cline (Kenneth.Cline@cs.cmu.edu)
	Fox Project
	School of Computer Science
	Carnegie Mellon University
	Pittsburgh, Pa 15139-3891

		i.	Abstract




		ii.	Table of Contents

	i.	Abstract
	ii.	Table of Contents
	iii.	RCS Log
	1.	

		iii.	RCS Log
	
$Log: header.c,v $
Revision 1.4  1996/03/08  23:34:13  esb
removed Brian

Revision 1.3  1994/03/02  21:45:15  esb
minor change

Revision 1.2  1993/09/10  13:50:59  cline
replaced Nick with Ken

Revision 1.1  93/06/10  21:35:35  milnes
Initial revision

*/


/*
		1.	...
*/

